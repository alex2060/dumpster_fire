import os
import time
os.system("cd "+os.getcwd())
print("in right place")

os.system("/Applications/Blender/blender.app/Contents/MacOS/blender img_base.blend --background --python make_img_breaker.py")
time.sleep(2)
os.system("/Applications/Blender/blender.app/Contents/MacOS/blender myimg_breaker.blend --background -a")
print("make_imges")

os.system("python3 GS_remover.py")

print("made_gs")
os.system("python3 obj_maker.py")
print("make_obj")
#quit()
os.system("/Applications/Blender/blender.app/Contents/MacOS/blender working_2.blend --background --python insert_and_extrude.py")
print("about to animate")
#os.system("/Applications/Blender/blender.app/Contents/MacOS/blender insert_1.blend --background -a")
print("done")
