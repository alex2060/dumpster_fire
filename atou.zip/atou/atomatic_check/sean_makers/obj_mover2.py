
def number_fixer(number):
	if len(str(number))==1:
		return "00"+str(number)
	if len(str(number))==2:
		return "0"+str(number)
	return str(number)
f = open("full_rocker.txt", "w")

for x in range(600):
	pass
	#f.write("l,3dframe"+str(x)+",0,0,-30,"+str(0)+"\n")
	f.write("l,3dframe"+str(x)+",0,0,0,"+str(x+30)+"\n")
	f.write("l,3dframe"+str(x)+",0,0,-30,"+str(x-15)+"\n")
	
	
	
	if x%4==0:
		f.write("c,3dframe"+str(x)+",0.8,0.051359,0.038503,"+str(x+15)+"\n")
	if x%4==1:
		f.write("c,3dframe"+str(x)+",0.066613,0.278731,0.8,"+str(x+15)+"\n")
	if x%4==2:
		f.write("c,3dframe"+str(x)+",0.87,0.05,0.83,"+str(x+15)+"\n")

	if x%4==3:
		f.write("c,3dframe"+str(x)+",0.87,0.45,0.83,"+str(x+15)+"\n")
	#if x%4==3:
		#f.write("c,3dframe"+str(x)+",0.9,0.9,0,"+str(x+15)+"\n")
	#if x%4==4:
		#f.write("c,3dframe"+str(x)+",0.9,0,0.9,"+str(x+15)+"\n")
	#f.write("l,3dframe"+str(x)+",0,0,0,"+str(x+105)+"\n")
	#f.write("l,Plane_frame."+number_fixer(x)+",0,-"+str(x*0.125+0.001)+",100,"+str(x+1)+"\n")
f.close()