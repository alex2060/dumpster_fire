import os
import bpy

vals=[0]*5
couter=0

f = open(os.getcwd()+"/sean/base_data_file.txt", "r")
for x in f:
  print(x)
  output=x.split(",")
  vals[couter]=output[1].strip("\n")
  couter=couter+1
 
bpy.context.scene.frame_end = int(vals[4])
bpy.context.scene.render.filepath = os.getcwd()+"/ims/"
bpy.context.scene.sequence_editor.sequences.new_movie(filepath=os.getcwd()+"/video.mp4",channel=1,frame_start=1,name="no_name")
bpy.ops.wm.save_as_mainfile(filepath="myimg_breaker.blend")
#blender -b myimg_breaker.blend -a