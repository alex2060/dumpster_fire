

def number_fixer(x):
	if len(str(x))==1:
		return "00"+str(x)
	if len(str(x))==2:
		return "0"+str(x)
	if len(str(x))==3:
		return ""+str(x)
	return str(x)
f = open("img_deleter.txt", "w")
number=135
for x in range(600):
	f.write("del,2d_frame."+number_fixer(number)+",0\n")
	number=number+1
f.close()
